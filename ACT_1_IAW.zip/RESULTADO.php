 <!DOCTYPE html>
<html>
<head>
    <title>RESULTADO LOGIN</title>
</head>
<body>
<?php
$rol = 'Usuario';
switch($rol){
    case 'Admin':
        echo '<h3 syle="color:green">Prueba superada fantastico!</h3>';
        echo ' <a href="Data.php"> ACCESO A DATOS </a>';
        break;
    case 'Usuario':
        echo '<h3 style="color:blue">Prueba superada al limite</h3>';
        echo ' <a href="Data.php"> ACCESO A DATOS </a>';
        break;
    default:
        echo '<h3 style="color:red">Prueba no superada</h3>';
        break;
}
?>
</body>
</html>