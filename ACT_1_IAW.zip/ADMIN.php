<!DOCTYPE html>
<html>
<head>
    <title>DATA</title>
</head>
<body>
<h2>DATOS</h2>
<?php
    $rol = 'Admin';
    if($rol == 'Admin'){
        echo '<h3 style="color:green">Contraseña correcta </h3>';
    }
    else{
        echo '<h3 style="color:red">Prueba suspendida</h3>';
    }
    ?>
</body>
</html>