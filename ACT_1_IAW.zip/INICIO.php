<!DOCTYPE html>
<html>
<head>
    <title>INICIO</title>
</head>
<?php
    $contraseña = 4;
    //metodos de comparacion: <=, <, >, >=, ==(comparar), =(igual)
    if($contraseña == 4){
        echo '<h3 style="color:green">Contraseña correcta </h3>';
        echo ' <a href="resultado.php">LOGIN</a>';
    }
    else{
        echo '<h3 style="color:red">Prueba suspendida</h3>';
    }
    ?>
</body>
</html>