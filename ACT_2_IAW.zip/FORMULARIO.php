<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>APPWEB</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      text-align: center;
      margin: 20px;
    }
    form {
      max-width: 300px;
      margin: 20px auto;
    }
    input {
      width: 100%;
      margin-bottom: 10px;
    }
  </style>
</head>
<body>

  <form action="LOGIN.php" method="post">
    <h2>Iniciar sesión</h2>
      <label for="user">Usuario:</label>
      <input type="text" id="user" name="user" required>
      <label for="password">Contraseña:</label>
      <input type="password" id="password" name="password" required>
      <button type="submit">Iniciar sesión</button>
  </form>

  <form action="REGISTER.php" method="post">
    <h2>Registro</h2>
      <label for="NewUser">Nuevo Usuario:</label>
      <input type="text" id="NewUser" name="NewUser" required>
      <label for="newPassword">Nueva Contraseña:</label>
      <input type="password" id="NewPassword" name="NewPassword" required>
      <button type="submit">Registrarse</button>
  </form>

</body>
</html>
