<?php
$users = ["user1" => "password1", "user2" => "password2"]; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $NewUser = $_POST["NewUser"];
    $NewPassword = $_POST["NewPassword"];

    if (isset($users[$NewUser])) {
        echo "Usuario existente";
    } else {
        $users[$NewUser] = $NewPassword;
        echo "Usuario creado";
    }
}
?>
