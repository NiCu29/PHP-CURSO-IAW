<?php
$users = ["NicuA" => "nicua", "usuario2" => "password2"]; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    if (isset($users[$username]) && $users[$username] === $password) {
        echo "Acceso permitido";
    } else {
        echo "Acceso denegado";
    }
}
?>
